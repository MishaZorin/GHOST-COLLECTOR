import { Strategy } from "passport-local";
import { PassportStrategy } from "@nestjs/passport";
import { Injectable, UnauthorizedException } from "@nestjs/common";
import { AuthService } from "./auth.service";
@Injectable()
export class LocalStrategy extends PassportStrategy(Strategy) {
  constructor( private readonly authService: AuthService,) {
    // super() вызывает конструктор родительского класса PassportStrategy.
// По умолчанию стратегия passport-local ожидает поля:
    super({ usernameField: "email" });
  }

  async validate(email: string, password: string) {
    const user = await this.authService.validateUser(email, password);
    if (!user) throw new UnauthorizedException();
    return user;
  }
}

// LocalStrategy — отвечает за аутентификацию по логину и паролю.
// JwtStrategy — отвечает за проверку токена при каждом последующем запросе к защищённым маршрутам.